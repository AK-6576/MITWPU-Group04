//
//  Conversations.swift
//  ANSD_APP
//
//  Created by SDC-USER on 06/01/26.
//

import Foundation

// MARK: - Message Model

// Represents a single message in a conversation with sender information and metadata
struct Message: Codable, Identifiable, Sendable {
    var id: UUID = UUID()
    var text: String
    let senderName: String
    let isIncoming: Bool
    var isHighlighted: Bool = false
    var senderId: String = "other"
    var timestamp: Date = Date()
    
    enum CodingKeys: String, CodingKey {
        case text, senderName, isIncoming, isHighlighted, id
    }
    
    // Standard initializer for creating messages programmatically
    init(id: UUID = UUID(), text: String, senderId: String, senderName: String, isIncoming: Bool, timestamp: Date = Date(), isHighlighted: Bool = false) {
        self.id = id
        self.text = text
        self.senderId = senderId
        self.senderName = senderName
        self.isIncoming = isIncoming
        self.timestamp = timestamp
        self.isHighlighted = isHighlighted
    }
    
    // Custom decoder for loading messages from JSON
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        text = try container.decode(String.self, forKey: .text)
        senderName = try container.decode(String.self, forKey: .senderName)
        isIncoming = try container.decode(Bool.self, forKey: .isIncoming)
        isHighlighted = try container.decodeIfPresent(Bool.self, forKey: .isHighlighted) ?? false
        id = UUID()
        senderId = isIncoming ? "other" : "me"
        timestamp = Date()
    }
    
    // Custom encoder for saving messages to JSON
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(text, forKey: .text)
        try container.encode(senderName, forKey: .senderName)
        try container.encode(isIncoming, forKey: .isIncoming)
        try container.encode(isHighlighted, forKey: .isHighlighted)
        try container.encode(id.uuidString, forKey: .id)
    }
}

// MARK: - Participant Model

// Represents a participant in a conversation with their name and summary
struct PCParticipantData: Codable, Sendable {
    let name: String
    let summary: String
}

// MARK: - Conversation Model

// Represents a complete conversation with metadata, participants, and messages
struct Conversation: Codable, Identifiable, Sendable {
    let id: String
    var title: String
    var description: String
    var date: String
    var startTime: String
    var endTime: String
    var category: String
    var icon: String
    var info: Bool?
    var cal: Date?
    var notes: String?
    var participants: [PCParticipantData]?
    var isPinned: Bool = false
    var messages: [Message]?

    enum CodingKeys: String, CodingKey {
        case id, title, description, date, category, icon, info, notes, participants, messages
        case startTime = "start_time"
        case endTime = "end_time"
    }
    
    // Manual initializer for creating conversations programmatically
    init(id: String, title: String, messages: [Message] = [], participants: [PCParticipantData] = [], notes: String = "", description: String = "", date: String = "", startTime: String = "", endTime: String = "", category: String = "", icon: String = "") {
        self.id = id
        self.title = title
        self.messages = messages
        self.participants = participants
        self.notes = notes
        self.description = description
        self.date = date
        self.startTime = startTime
        self.endTime = endTime
        self.category = category
        self.icon = icon
    }
}

// MARK: - Response Container Models

// Represents a month of previous conversations
struct PreviousMonth: Codable, Sendable {
    let month: String
    var conversations: [Conversation]
}

// Main container for all conversations data from JSON
struct ConversationsResponse: Codable, Sendable {
    var conversations: [Conversation] = []
    var previousMonths: [PreviousMonth] = []

    enum CodingKeys: String, CodingKey {
        case conversations
        case previousMonths = "previous_months"
    }
    
    // Initializes by attempting to load conversations from JSON file
    init() {
        if let response = try? Self.load() {
            self.conversations = response.conversations
            self.previousMonths = response.previousMonths
        }
    }
    
    // Loads and decodes conversations from a JSON file in the app bundle
    static func load(from filename: String = "conversations") throws -> ConversationsResponse {
        guard let url = Bundle.main.url(forResource: filename, withExtension: "json") else {
            throw NSError(domain: "ConversationsResponse", code: 404,
                          userInfo: [NSLocalizedDescriptionKey: "conversations.json not found"])
        }

        let data = try Data(contentsOf: url)
        let decoder = JSONDecoder()
        return try decoder.decode(ConversationsResponse.self, from: data)
    }
}
